/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.UsuarioVO;
import DAO.UsuarioDAO;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mille
 */
@WebServlet(name = "UsuarioControlador", urlPatterns = {"/Usuario"})
public class UsuarioControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String menu = request.getParameter("menu");
        String idVigilante = request.getParameter("txtIdVigilante");
        String usuario = request.getParameter("txtUsuario");
        String rol = request.getParameter("txtRol");
        String clave = request.getParameter("txtClave");
        UsuarioVO usuVO = new UsuarioVO(idVigilante, usuario, rol, clave);
        UsuarioDAO usuDAO = new UsuarioDAO(usuVO);
        switch (menu) {
            case "1":
                if (usuario.equals("") || clave.equals("")) {
                    request.setAttribute("MensajeBlancoI","Complete los campos vacios.");   
                } else {
                    if (usuDAO.validarUsuario(usuario, clave)) {
                        ArrayList<UsuarioVO> listaUsu = usuDAO.IniciarSesion(usuario, clave);
                        if (listaUsu == null) {
                            UsuarioVO usuVoS = listaUsu.get(0);                            
                            HttpSession sesion = request.getSession(false);
                            sesion.setAttribute("usuarioS", usuVoS);
                            request.setAttribute("MensajeErrorI", "El usuario y/o contraseña son incorrectas");                            
                        } else {
                            UsuarioVO usuVoS = listaUsu.get(0);
                            HttpSession sesion = request.getSession(true);
                            sesion.setAttribute("usuarioS", usuVoS);
                            if (usuVoS.getRol().equals("Administrador")) {
                                request.getRequestDispatcher("MenuPrincipal.jsp").forward(request, response);
                            } else if (usuVoS.getRol().equals("Vigilante")) {
                                request.getRequestDispatcher("MenuSecundario.jsp").forward(request, response);
                            }
                        }
                    } else {
                        request.setAttribute("MensajeErrorI", "El usuario y/o contraseña son incorrectas");
                       
                    }
                }    
                 request.getRequestDispatcher("Index.jsp").forward(request, response);
                break;
            case "2":
                if (usuDAO.Registrar()) {
                    request.setAttribute("MensajeExito", "");
                    request.getRequestDispatcher("").forward(request, response);
                } else {
                    request.setAttribute("MensajeError", "");
                    request.getRequestDispatcher("").forward(request, response);
                }
                break;
            case "3":
                if (usuDAO.Editar()) {
                    request.setAttribute("MensajeExito", "");
                    request.getRequestDispatcher("").forward(request, response);
                } else {
                    request.setAttribute("MensajeError", "");
                    request.getRequestDispatcher("").forward(request, response);
                }
                break;
            case "4":               
                //Cerrar Sesión
            
                HttpSession sesion = request.getSession();
                sesion.invalidate();                
                request.getRequestDispatcher("Index.jsp").forward(request, response);
                break;
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
