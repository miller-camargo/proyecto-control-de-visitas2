/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.ElementoVO;
import DAO.ElementoDAO;
/**
 *
 * @author mille
 */
@WebServlet(name = "ElementoControlador", urlPatterns = {"/Elemento"})
public class ElementoControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        int menu = Integer.parseInt(request.getParameter("menu"));
        String serial = request.getParameter("txtSerial");
        String piso = request.getParameter("txtPiso");
        String marca = request.getParameter("txtMarca");
        String categoria = request.getParameter("txtCategoria");
        String descripcion = request.getParameter("txtDescripcion");
        String idVisitante = request.getParameter("txtIdVisitante");        
        
        ElementoVO eleVO=new ElementoVO(piso,serial,marca,categoria,descripcion,idVisitante);
        ElementoDAO eleDAO=new ElementoDAO(eleVO);
       
         switch(menu){
            case 1:
                if (serial.equals("") || marca.equals("") || categoria.equals("") || descripcion.equals("") || idVisitante.equals("")) {
                    request.setAttribute("MensajeCamposVacios","Complete los campos vacios.");               
                } else {
                    if (eleDAO.Registrar()) {                        
                        request.setAttribute("MensajeExito", "El elemento ha sido registrado con exito.");                        
                    } else {
                        request.setAttribute("MensajeError", "El elemento ya esta registrado.");                        
                    }
                }
                request.getRequestDispatcher("RegistrarVisita.jsp").forward(request, response);
                break;                          
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
