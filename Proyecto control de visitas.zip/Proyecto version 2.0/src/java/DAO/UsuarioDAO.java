/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.ArrayList;
import util.ConexionBD;
import util.Metodos;
import VO.UsuarioVO;
import VO.VigilanteVO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author APRENDIZ
 */
public class UsuarioDAO extends ConexionBD implements Metodos {

    private Connection conexion = null;
    private Statement puente = null;
    private ResultSet mensajero = null;

    private String idVigilante = "";////preguntar que se pone 
    private String usuario = "";
    private String rol = "";
    private String clave = "";
    private boolean operacion = false;

    public UsuarioDAO(UsuarioVO usuVO) {
        super();
        try {
            conexion = this.odtenerConecion();
            puente = conexion.createStatement();
            idVigilante = usuVO.getIdVigilante();
            usuario = usuVO.getUsuario();
            clave = usuVO.getClave();
            rol = usuVO.getRol();

        } catch (Exception e) {
            System.out.println("Error en el contructor principal :" + e.toString());
        }
    }

    @Override
    public boolean Registrar() {
        try {
            puente.executeUpdate("INSERT INTO `usuario`(`usuario`, `clave`, `rol`, `ID_Vigilante`) VALUES ('"+usuario+"','"+clave+"','"+rol+"','"+idVigilante+"')");
            operacion = true;
        } catch (SQLException ex) {
            System.out.println("Error al registrar el usuario:" + ex.toString());
        }
        return operacion;
    }

    @Override
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `usuario` SET `clave`='"+clave+"' WHERE `ID_Vigilante`='"+idVigilante+"'");
            operacion = true;
        } catch (SQLException ex) {
            System.out.println("Error al atualizar el usuario:" + ex.toString());
        }
        return operacion;
    }

    @Override
    public ArrayList<UsuarioVO> ConsultarT() {
        ConexionBD con = new ConexionBD();
        ArrayList<UsuarioVO> listaUsu = new ArrayList<UsuarioVO>();
        try {
            puente = con.odtenerConecion().createStatement();
            mensajero = puente.executeQuery("SELECT * FROM `usuario` ");
            while (mensajero.next()) {
                idVigilante = mensajero.getString(1);
                usuario = mensajero.getString(1);
                clave = mensajero.getString(1);
                rol = mensajero.getString(1);

                UsuarioVO usuVO = new UsuarioVO(idVigilante, usuario, rol, clave);
                listaUsu.add(usuVO);
            }
        } catch (Exception e) {
            System.out.println("Error al llenar arraylist consulat: " + e.toString());
        }
        return listaUsu;
    }

    public static UsuarioVO consultarEstado(String estado) {
        UsuarioVO usuVO = null;
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente = conexion.createStatement();
            ResultSet mensajero=puente.executeQuery("");
            while (mensajero.next()) {
               usuVO=new UsuarioVO(mensajero.getString(1),mensajero.getString(1), mensajero.getString(1),mensajero.getString(0));                
            }
            mensajero.close();
            puente.close();
        } catch (Exception e) {
            System.out.println("Error en la consulta : "+e.toString());
        }
        return usuVO;
    }

    public static UsuarioVO recuperrarClave(String correo) {
        UsuarioVO usuVO= null;
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensajero = puente.executeQuery("SELECT u.ID_Vigilante,u.usuario,u.rol FROM `usuario` U NATURAL JOIN vigilante V where v. ;");
            while (mensajero.next()) {
                usuVO =new UsuarioVO(mensajero.getString(1),mensajero.getString(1), mensajero.getString(1),mensajero.getString(0));                
            }
            mensajero.close();
            puente.close();
        } catch (Exception e) {
            System.out.println("Error en la consulta : "+e.toString());
        }
        return usuVO;
    }
    public boolean validarUsuario(String usuario,String contraseña){
        try {
            conexion=this.odtenerConecion();
            puente=conexion.createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `usuario` WHERE usuario='"+usuario+"' and clave='"+clave+"'");
            if (mensajero.next()) {
                operacion=true;                
            }
            this.cerrarConexion();
        } catch (Exception e) {
            System.out.println("Error al iniciar sesion : "+e.toString());
        }
        return  operacion;
    }
    public ArrayList<UsuarioVO> IniciarSesion(String usuarioA, String claveA){       
         ConexionBD conBD= new ConexionBD();
        ArrayList<UsuarioVO> lista= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero = puente.executeQuery("SELECT * FROM `usuario` WHERE usuario='"+usuarioA+"' and clave='"+claveA+"'");
            while (mensajero.next()) {                
                idVigilante= mensajero.getString(4);
                usuario= mensajero.getString(1);
                clave= mensajero.getString(2);
                rol= mensajero.getString(3);
                UsuarioVO usuVO= new UsuarioVO(idVigilante, usuario, rol, clave);
                lista.add(usuVO);
            }
        }catch (Exception e) {
            System.out.println("Error: " + e.toString());

        }
        return lista;
    }
    
    
}
