/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import util.*;
import VO.VisitaVO;
import VO.VisitanteVO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author mille
 */
public class VisitaDAO extends ConexionBD implements Metodos{
    private Connection conexion;
    private Statement puente;
    private ResultSet mensajero;
    private String idVista="",FechaInicio="",FechaFin="",HoraInicio="" ,HoraFin="",IdVigilante="",idPaciente="",idVisitante="", Estado="";
    private boolean operacion=false;

    public VisitaDAO(VisitaVO visVO) {
        super();
        try {
            conexion= this.odtenerConecion();
            puente=conexion.createStatement();
            
            idPaciente=visVO.getIdPaciente();
            IdVigilante=visVO.getIdVigilante();
            idVista=visVO.getIdVista();
            idVisitante=visVO.getIdVisitante();
            HoraFin=visVO.getHoraFin();
            HoraInicio=visVO.getHoraInicio();
            FechaFin=visVO.getFechaFin();
            FechaInicio=visVO.getFechaInicio();
            Estado=visVO.getEstado();
        } catch (Exception e) {
            System.out.println("Error en el constructor : "+e.toString());
        }
    }

    
    
    @Override
    public boolean Registrar() {
        try {
            puente.executeUpdate("CALL Reg_Visita ('"+FechaInicio+"','"+HoraInicio+"','"+HoraFin+"','"+idVisitante+"','"+idPaciente+"','"+IdVigilante+"','"+FechaFin+"','"+Estado+"')");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Error al registrar la visita :"+e.toString());
        }
        return operacion;
    }

    public VisitaDAO() {
    }

    @Override
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `visita` SET `Hora_Fin`='"+HoraFin+"',`FechaFin`='"+FechaFin+"', Estado= 'Finalizado' WHERE `ID_Vista`='"+idVista+"'");
            operacion=true;
        } catch (SQLException ex) {
            System.out.println("Error al actualizar la visita");
        }
        return operacion;
    }

    @Override
    public ArrayList<VisitaVO> ConsultarT() {
    ConexionBD conBD =new ConexionBD();
    ArrayList<VisitaVO> listaVis= new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `visita` ");
            while (mensajero.next()) {
                Estado=mensajero.getString(9);
                idPaciente=mensajero.getString(6);
                IdVigilante=mensajero.getString(7);
                idVista=mensajero.getString(1);
                idVisitante=mensajero.getString(5);
                FechaFin=mensajero.getString(8);
                FechaInicio=mensajero.getString(2);
                HoraFin=mensajero.getString(4);
                HoraInicio=mensajero.getString(3);
                VisitaVO visVO=new VisitaVO(idVista, FechaInicio, FechaFin, HoraInicio, HoraFin, IdVigilante, idPaciente, idVisitante, Estado);
                listaVis.add(visVO);                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar las visitas"+e.toString());
        }
        return listaVis;
    }
    
    public ArrayList<VisitaVO> ConsultarPorPaciente(String Paciente) {
    ConexionBD conBD =new ConexionBD();
    ArrayList<VisitaVO> listaVis= new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `visita` where ID_Paciente="+Paciente);
            while (mensajero.next()) {
                Estado=mensajero.getString(9);
                idPaciente=mensajero.getString(6);
                IdVigilante=mensajero.getString(7);
                idVista=mensajero.getString(1);
                idVisitante=mensajero.getString(5);
                FechaFin=mensajero.getString(8);
                FechaInicio=mensajero.getString(2);
                HoraFin=mensajero.getString(4);
                HoraInicio=mensajero.getString(3);
                VisitaVO visVO=new VisitaVO(idVista, FechaInicio, FechaFin, HoraInicio, HoraFin, IdVigilante, idPaciente, idVisitante, Estado);
                listaVis.add(visVO);                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar las visitas"+e.toString());
        }
        return listaVis;
    }
     
      public static VisitaVO ConsultarPorPaciente2(String Paciente) {
         VisitaVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `visita` where ID_Paciente="+Paciente);
            while (mensejero.next()){
                visVo= new VisitaVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6), mensejero.getString(7), mensejero.getString(8), mensejero.getString(9));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
      
       public ArrayList<VisitaVO> ConsultarPorVisitante(String Visitante) {
    ConexionBD conBD =new ConexionBD();
    ArrayList<VisitaVO> listaVis= new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `visita` where ID_Visitante="+Visitante);
            while (mensajero.next()) {
                Estado=mensajero.getString(9);
                idPaciente=mensajero.getString(6);
                IdVigilante=mensajero.getString(7);
                idVista=mensajero.getString(1);
                idVisitante=mensajero.getString(5);
                FechaFin=mensajero.getString(8);
                FechaInicio=mensajero.getString(2);
                HoraFin=mensajero.getString(4);
                HoraInicio=mensajero.getString(3);
                VisitaVO visVO=new VisitaVO(idVista, FechaInicio, FechaFin, HoraInicio, HoraFin, IdVigilante, idPaciente, idVisitante, Estado);
                listaVis.add(visVO);                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar las visitas"+e.toString());
        }
        return listaVis;
    }
     
      public static VisitaVO ConsultarPorVisitante2(String Visitante) {
         VisitaVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `visita` where ID_Paciente="+Visitante);
            while (mensejero.next()){
                visVo= new VisitaVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6), mensejero.getString(7), mensejero.getString(8), mensejero.getString(9));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;

      }
      public ArrayList<VisitaVO> ConsultarVisitaEP() {
    ConexionBD conBD =new ConexionBD();
    ArrayList<VisitaVO> listaVis= new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `visita` where Estado='En Proceso'");
            while (mensajero.next()) {
                Estado=mensajero.getString(9);
                idPaciente=mensajero.getString(6);
                IdVigilante=mensajero.getString(7);
                idVista=mensajero.getString(1);
                idVisitante=mensajero.getString(5);
                FechaFin=mensajero.getString(8);
                FechaInicio=mensajero.getString(2);
                HoraFin=mensajero.getString(4);
                HoraInicio=mensajero.getString(3);
                VisitaVO visVO=new VisitaVO(idVista, FechaInicio, FechaFin, HoraInicio, HoraFin, IdVigilante, idPaciente, idVisitante, Estado);
                listaVis.add(visVO);                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar las visitas"+e.toString());
        }
        return listaVis;
    }
       
}
