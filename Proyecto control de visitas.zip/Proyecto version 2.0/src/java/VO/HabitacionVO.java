/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VO;

/**
 *
 * @author APRENDIZ
 */
public class HabitacionVO {
    private int candPacientes,piso;
    private String numHabitacion,estado,horario,tipoHabitacion;

    public HabitacionVO(int candPacientes, int piso, String numHabitacion, String estado, String horario, String tipoHabitacion) {
        this.candPacientes = candPacientes;
        this.piso = piso;
        this.numHabitacion = numHabitacion;
        this.estado = estado;
        this.horario = horario;
        this.tipoHabitacion = tipoHabitacion;

    }

    public HabitacionVO() {
    }

    public HabitacionVO(int candPacientes, String horario, String tipoHabitacion) {
        this.candPacientes = candPacientes;
        this.horario = horario;
        this.tipoHabitacion = tipoHabitacion;
    }

    public HabitacionVO(int candPacientes, int piso) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    

    public int getCandPacientes() {
        return candPacientes;
    }

    public void setCandPacientes(byte candPacientes) {
        this.candPacientes = candPacientes;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(byte piso) {
        this.piso = piso;
    }      

    public String getNumHabitacion() {
        return numHabitacion;
    }

    public void setNumHabitacion(String numHabitacion) {
        this.numHabitacion = numHabitacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getTipoHabitacion() {
        return tipoHabitacion;
    }

    public void setTipoHabitacion(String tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }
    
       
}
