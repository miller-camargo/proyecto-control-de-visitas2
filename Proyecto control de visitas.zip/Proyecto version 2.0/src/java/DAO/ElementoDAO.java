/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.ConexionBD;
import util.Metodos;
import VO.ElementoVO;
import VO.VisitanteVO;
import java.sql.Array;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mille
 */
public class ElementoDAO extends ConexionBD {

    private Connection conexion;
    private Statement puente;
    private ResultSet mensajero;
    private String id = "", serial = "", marca = "", categoria = "", descripcion = "", idVisitante = "";
    private boolean operacion = false;

    public ElementoDAO(ElementoVO eleVO) {
        super();

        try {
            conexion = this.odtenerConecion();
            puente = conexion.createStatement();
            id = eleVO.getId();
            serial = eleVO.getSerial();
            marca = eleVO.getMarca();
            categoria = eleVO.getCategoria();
            descripcion = eleVO.getDescripcion();
            idVisitante = eleVO.getIdVisitante();
        } catch (SQLException ex) {
            System.out.println("Error en el constructor : " + ex.toString());
        }
    }

    public boolean Registrar() {
        try {
            puente.executeUpdate("INSERT INTO `elementos`(`ID_Visitante`, `MARCA`, `CATEGORIA`, `DESCRIPCION`, `serial`) VALUES ('"+idVisitante+"','"+marca+"','"+categoria+"','"+descripcion+"','"+serial+"')");
            operacion = true;
        } catch (Exception e) {
            System.out.println("Error al registrar el elemento : " + e.toString());
        }
        return operacion;
    }

    public ElementoDAO() {
    }

    public ArrayList<ElementoVO> ConsultarT() {
        ConexionBD conBD = new ConexionBD();
        ArrayList<ElementoVO> listaEle = new ArrayList<>();
        try {
            puente = conBD.odtenerConecion().createStatement();
            mensajero = puente.executeQuery("SELECT * FROM `elementos` NATURAL join visitante  WHERE ID_Visitante='"+idVisitante+"'");///arreglar
            while (mensajero.next()) {
                id = mensajero.getString(2);
                serial = mensajero.getString(2);
                marca = mensajero.getString(3);
                categoria = mensajero.getString(4);
                descripcion = mensajero.getString(5);
                idVisitante = mensajero.getString(6);
                ElementoVO eleVO = new ElementoVO(id, serial, marca, categoria, descripcion, idVisitante);
                listaEle.add(eleVO);
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todos los elementos: " + e.toString());
        }
        return listaEle;
    }
    public static ElementoVO consultaElemtos(String idVisitante){
        ElementoVO eleVO=null;
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensajero= puente.executeQuery("SELECT * FROM `elementos` WHERE ID_Visitante='"+idVisitante+"';");
            while (mensajero.next()){
                eleVO=new ElementoVO(mensajero.getString(1),mensajero.getString(6),mensajero.getString(3),mensajero.getString(4),mensajero.getString(5),mensajero.getString(2));                
            }
             mensajero.close();
             puente.close();
        } catch (Exception e) {
            System.out.println("Error al consultar los elemtentos");
        }
        return eleVO;
    }
    
      public static ElementoVO ConsultarPorVisitante2(String Nombre) {
         ElementoVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `elementos` where ID_Visitante='"+Nombre+"'");
            while (mensejero.next()){
                visVo= new ElementoVO(mensejero.getString(1), mensejero.getString(6), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(2));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
      public ArrayList<ElementoVO> ConsultarPorVisitante(String Nombre) {
        ConexionBD conBD= new ConexionBD();
        ArrayList<ElementoVO> listaVis= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `elementos` where ID_Visitante='"+Nombre+"'");
            while (mensajero.next()){
                
                idVisitante=mensajero.getString(2);
                id=mensajero.getString(1);
                marca=mensajero.getString(3);
                categoria=mensajero.getString(4);
                descripcion=mensajero.getString(5);
                serial=mensajero.getString(6);
                ElementoVO visVO= new ElementoVO(id, serial,marca ,categoria, descripcion, idVisitante);
                listaVis.add(visVO);                                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaVis;
    }

}
