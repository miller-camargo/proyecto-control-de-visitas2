/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.HabitacionVO;
import DAO.HabitacionDAO;
import DAO.PacienteDAO;
import DAO.VisitanteDAO;
import VO.PacienteVO;
import VO.VisitanteVO;

/**
 *
 * @author mille
 */
@WebServlet(name = "ContriladorHabitacion", urlPatterns = {"/Habitacion"})
public class HabitacionControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String menu = request.getParameter("menu");
        String candPacientes = request.getParameter("txtCadPaciente");
        String piso = request.getParameter("txtPiso");
        String numHabitacion = request.getParameter("txtNumeroHabitacion");
        String estado = request.getParameter("txtEstado");
        String horario = request.getParameter("txtHorario");
        String tipoHabitacion = request.getParameter("txtHorario");

        switch (menu) {
            case "1":
                HabitacionVO habVO = new HabitacionVO(Integer.parseInt(candPacientes), Integer.parseInt(piso), numHabitacion, estado, horario, tipoHabitacion);
                HabitacionDAO habDAO = new HabitacionDAO(habVO);
                if (candPacientes.equals("") || piso.equals("") || numHabitacion.equals("") || estado.equals("") || horario.equals("") || tipoHabitacion.equals("")) {
                    request.setAttribute("MensajeCamposVacios", "Complete los campos vacios.");
                } else if (habDAO.Registrar()) {
                    request.setAttribute("MensajeExito", "La habitación ha sido registrada con exito.");
                } else {
                    request.setAttribute("MensajeError", "La habitación ya esta registrada.");
                }
                request.getRequestDispatcher("RegistrarHabitacion.jsp").forward(request, response);
                break;
            case "2":
                String idVis = request.getParameter("txtId");
                HabitacionVO visVO1 = HabitacionDAO.ConsultarPorNumero(idVis);

                if (visVO1 != null) {
                    request.setAttribute("lista", visVO1);
                    request.getRequestDispatcher("ActualizarHabitacion.jsp").forward(request, response);
                } else {
                    request.setAttribute("MensajeError", "El vehiculo no existe desea registrarlo ");
                }
                break;
            case "3":
                HabitacionVO habVO2 = new HabitacionVO(Integer.parseInt(candPacientes), Integer.parseInt(piso), numHabitacion, estado, horario, tipoHabitacion);
                HabitacionDAO habDAO2 = new HabitacionDAO(habVO2);
                if (habDAO2.Editar()) {
                    request.setAttribute("MensajeExitoa", "El visitante se ha actualizado con exito.");

                } else {
                    request.setAttribute("MensajeErrora", "El visitante no se puedo actualizar");
                }
                request.getRequestDispatcher("ConsultarVisitante.jsp").forward(request, response);
                break;
                case "Consultar": 
                    String Num= request.getParameter("selecNumero"); 
                    String Est= request.getParameter("selecEstado"); 
                    if (Num.equals("") &&  Est.equals("")) {                        
                        request.setAttribute("lista", null);
                    }                   
                    else
                    {
                        if(Num.length() > 1)
                        {
                            HabitacionVO pacVO2 = HabitacionDAO.ConsultarPorId(Num);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaN", pacVO2);
                                 request.getRequestDispatcher("ConsultarHabitacion.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "No hay pacientes regitrados en esta habitación <br>");                                                
                             }                            
                        }   
                        else if(Est.length() > 1)
                        {
                            HabitacionVO pacVO2 = HabitacionDAO.ConsultarPorEstado2(Est);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaE", pacVO2);
                                 request.getRequestDispatcher("ConsultarHabitacion.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "La habitacion no esta registrada en la base de datos. <br>");                                                
                             }                            
                        }                          
                    }                   
                     request.getRequestDispatcher("ConsultarHabitacion.jsp").forward(request, response);
                break; 
                        
                        
                    
                 case "Reporte":             
                //Reportes
                break; 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
