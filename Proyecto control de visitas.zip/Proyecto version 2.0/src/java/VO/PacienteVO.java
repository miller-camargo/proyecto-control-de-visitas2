/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VO;

/**
 *
 * @author APRENDIZ
 */
public class PacienteVO extends  Persona{
    
    private String desEnfermedad,fechaNacimiento,idHabitacion; 
    

    public PacienteVO(String desEnfermedad, String fechaNacimiento, String id, String nombre, String apellido, String estado,String idHabitacion) {
        super(id, nombre, apellido, estado);        
        this.desEnfermedad = desEnfermedad;
        this.fechaNacimiento = fechaNacimiento;
        this.idHabitacion=idHabitacion;
    }

    public PacienteVO() {
    }
    

    public String getDesEnfermedad() {
        return desEnfermedad;
    }

    public void setDesEnfermedad(String desEnfermedad) {
        this.desEnfermedad = desEnfermedad;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(String idHabitacion) {
        this.idHabitacion = idHabitacion;
    }
    
    
    
    
}
