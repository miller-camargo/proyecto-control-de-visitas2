/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.HabitacionDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import VO.PacienteVO;
import DAO.PacienteDAO;
import DAO.VisitanteDAO;
import VO.HabitacionVO;
import VO.UsuarioVO;
import VO.VisitanteVO;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mille
 */
@WebServlet(name = "PacienteControlador", urlPatterns = {"/Paciente"})
public class PacienteControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String menu = request.getParameter("menu");
        String id = request.getParameter("txtIdentificacion");
        String nombre = request.getParameter("txtNombre");
        String estado = request.getParameter("txtEstado");;
        String apellido = request.getParameter("txtApellidos");
        String fechaNacimiento = request.getParameter("txtFechaNacimiento");
        String desEnfermedad = request.getParameter("txtDescripcionEnfermedad");
        String idHabitacion = request.getParameter("txtHabitacion");
        PacienteVO pacVO = new PacienteVO(desEnfermedad, fechaNacimiento, id, nombre, apellido, estado, idHabitacion);
        PacienteDAO pacDAO = new PacienteDAO(pacVO);

        switch (menu) {
            case "1":
                HabitacionVO habVO = new HabitacionVO();
                HabitacionDAO habDAO = new HabitacionDAO(habVO);
                if (id.equals("") || nombre.equals("") || apellido.equals("") || fechaNacimiento.equals("") || desEnfermedad.equals("") || idHabitacion.equals("")) {
                    request.setAttribute("MensajeCamposVacios", "Complete los campos vacios.");
                } 
                    else {
                        if (pacDAO.Registrar()) {
                            request.setAttribute("MensajeExito", "El paciente se ha registrado.");
                        } else {
                            request.setAttribute("MensajeError", "El paciente ya existe en la base de datos.");
                        }
                    }
                        
                request.getRequestDispatcher("RegistrarPaciente.jsp").forward(request, response);
                break;    
            case "2":
                 String idVis= request.getParameter("txtId");
                 PacienteVO pacVO1 = PacienteDAO.ConsultarPorId(idVis);

                    if (pacVO1 != null) {                       
                        request.setAttribute("lista", pacVO1);
                        request.getRequestDispatcher("ActualizarPaciente.jsp").forward(request, response);
                    } else {
                        request.setAttribute("MensajeError", "El vehiculo no existe desea registrarlo ");                                                
                    }
                    break;
            case "3":             
                if (pacDAO.Editar()) {
                    request.setAttribute("MensajeExitoa", "El visitante se ha actualizado con exito.");
                    
                } else {
                    request.setAttribute("MensajeErrora", "El visitante no se puedo actualizar");
                }               
                request.getRequestDispatcher("ConsultarPaciente.jsp").forward(request, response);
                break; 
                case "Consultar": 
                    String idpac= request.getParameter("selecID"); 
                    String Numhab= request.getParameter("selecHabitacion"); 
                    if (idpac.equals("") &&  Numhab.equals("")) {                        
                        request.setAttribute("lista", null);
                    }                   
                    else
                    {
                        if(idpac.equals(("")))
                        {
                            PacienteVO pacVO2 = PacienteDAO.ConsultarPorHabitacion(Numhab);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaH", pacVO2);
                                 request.getRequestDispatcher("ConsultarPaciente.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "No hay pacientes regitrados en esta habitación <br>");                                                
                             }                            
                        }   
                        else if(Numhab.equals(""))
                        {
                            PacienteVO pacVO2 = PacienteDAO.ConsultarPorId(idpac);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaP", pacVO2);
                                 request.getRequestDispatcher("ConsultarPaciente.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Paciente no esta registrado en la base de datos. <br>");                                                
                             }
                            
                        }   
                       
                    }                   
                     request.getRequestDispatcher("ConsultarPaciente.jsp").forward(request, response);
                break; 
                        
                        
                    
                 case "Reporte":             
                //Reportes
                break; 
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
        public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
