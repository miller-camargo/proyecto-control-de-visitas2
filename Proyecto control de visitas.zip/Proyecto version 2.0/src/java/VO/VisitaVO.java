/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VO;

/**
 *
 * @author mille
 */
public class VisitaVO {
    
    private String idVista,FechaInicio,FechaFin,HoraInicio,HoraFin,idVigilante,idPaciente,idVisitante,Estado;

    public VisitaVO(String idVista, String FechaInicio, String FechaFin, String HoraInicio, String HoraFin, String idVigilante, String idPaciente, String idVisitante, String Estado) {
        this.idVista = idVista;
        this.FechaInicio = FechaInicio;
        this.FechaFin = FechaFin;
        this.HoraInicio = HoraInicio;
        this.HoraFin = HoraFin;        
        this.idVigilante = idVigilante;
        this.idPaciente = idPaciente;
        this.idVisitante = idVisitante;
        this.Estado = Estado;
        
    }

    public String getIdVista() {
        return idVista;
    }

    public void setIdVista(String idVisita) {
        this.idVista = idVisita;
    }

    public String getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(String FechaInicio) {
        this.FechaInicio = FechaInicio;
    }
    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String FechaFin) {
        this.FechaFin = FechaFin;
    }

    public String getHoraInicio() {
        return HoraInicio;
    }

    public void setHoraInicio(String HoraInicio) {
        this.HoraInicio = HoraInicio;
    }

    public String getHoraFin() {
        return HoraFin;
    }

    public void setHoraFin(String HoraFin) {
        this.HoraFin = HoraFin;
    }  

    public String getIdVigilante() {
        return idVigilante;
    }

    public void setIdVigilante(String idVigilante) {
        this.idVigilante = idVigilante;
    }

    public String getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(String idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getIdVisitante() {
        return idVisitante;
    }

    public void setIdVisitante(String idVisitante) {
        this.idVisitante = idVisitante;
    }

    public VisitaVO() {
    }
    
    
}
