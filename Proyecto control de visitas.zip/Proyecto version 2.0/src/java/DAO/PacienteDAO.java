/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import VO.HabitacionVO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.ConexionBD;
import util.Metodos;
import VO.PacienteVO;
import VO.VigilanteVO;
import VO.VisitanteVO;
import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;



/**
 *
 * @author APRENDIZ
 */
public class PacienteDAO extends ConexionBD implements Metodos{
    
    private String id="";
    private String nombre="", estado="", apellido="",fechaNacimiento="",desEnfermedad="",idHabitacion="";
    
    private Connection conexion=null;
    private Statement puente=null;
    private ResultSet mensajero=null;
    
    private boolean operacion= false;
    public PacienteDAO(PacienteVO pacVO) {
        super();
        try {
            conexion=this.odtenerConecion();
            puente= conexion.createStatement();
            id=pacVO.getId();
            nombre=pacVO.getNombre();
            apellido=pacVO.getApellido();
            estado=pacVO.getEstado();
            fechaNacimiento=pacVO.getFechaNacimiento();
            desEnfermedad=pacVO.getDesEnfermedad();
            idHabitacion=pacVO.getIdHabitacion();
            
        } catch (Exception e) {
            System.out.println("Error en el constructor principal : "+e.toString());
        }
    }

    public PacienteDAO() {
    }

    
    @Override
    public boolean Registrar() {
        try {
            puente.executeUpdate("  CALL `Reg_Paciente`('"+id+"', '"+nombre+"', '"+apellido+"', '"+fechaNacimiento+"', '"+desEnfermedad+"', '"+idHabitacion+"','Activo');");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Error al registar el paciente : "+e.toString());
        }
        return operacion;
    }

    @Override
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `paciente` SET `Descripcion_Enfermedad`='"+desEnfermedad+"',`Numero_Habitacion`='"+idHabitacion+"',`Estado`='"+estado+"' WHERE `ID_Paciente`='"+id+"'");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Erorr al actualizar el paciente : "+e.toString());
        }
        return  operacion;
    }

    @Override
    public ArrayList<PacienteVO> ConsultarT() {
        ConexionBD conBD= new ConexionBD();
        ArrayList<PacienteVO> listaPac= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero= puente.executeQuery("SELECT * FROM `paciente`");
            while (mensajero.next()) {                
                id=mensajero.getString(1);
                nombre=mensajero.getString(2);
                apellido=mensajero.getString(3);                
                fechaNacimiento=mensajero.getString(4);
                desEnfermedad=mensajero.getString(5);
                idHabitacion=mensajero.getString(6);
                estado=mensajero.getString(7);
                PacienteVO pacVO=new PacienteVO(desEnfermedad, fechaNacimiento, id, nombre, apellido, estado, idHabitacion);
                listaPac.add(pacVO);
            }            
        } catch (Exception e) {
            System.out.println("Error al consultar los pacientes : "+e.toString());
        }
        return listaPac;
    }
    public static PacienteVO consultaEstado (String estado){
         PacienteVO pacVO=null;
         try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente = conexion.createStatement();
            ResultSet mensajero= puente.executeQuery("SELECT * FROM `paciente` WHERE Estado='"+estado+"';");
             while (mensajero.next()) {                 
                pacVO= new PacienteVO(mensajero.getString(5), mensajero.getString(4),mensajero.getString(1),mensajero.getString(2),mensajero.getString(3), mensajero.getString(7),mensajero.getString(6));                 
             }
             mensajero.close();
             puente.close();
        } catch (Exception e) {
             System.out.println("Error al consultar : "+e.toString());
        }
         return pacVO;
    }             
    public List<PacienteVO> ListarId(PacienteVO Paciente) {
            PreparedStatement instruccion=null;
            ResultSet resultado=null;
            List<PacienteVO> paciente = new ArrayList<PacienteVO>();
            
        odtenerConecion();

        try{
            String sSql = "";
            sSql = sSql + "SELECT ID_Paciente, Nombre_Paciente, Apellido_Paciente FROM paciente";

            instruccion = conexion.prepareStatement(sSql);

            resultado=instruccion.executeQuery();

            
            while (resultado.next()) {
                Paciente = new PacienteVO();
                Paciente.setId(resultado.getString(1));   
                Paciente.setNombre(resultado.getString(2));   
                Paciente.setApellido(resultado.getString(3));   
                paciente.add(Paciente);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
               if (resultado != null) resultado.close();
               if (instruccion != null) instruccion.close();
            } catch (SQLException ex) {
            }
        }

        return paciente;
        }
    
     public static PacienteVO ConsultarPorId(String id) {
         PacienteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT Descripcion_Enfermedad, Fecha_Nacimiento, ID_Paciente, Nombre_Paciente, Apellido_Paciente, Estado, Numero_Habitacion FROM `paciente` where ID_Paciente="+id);
            while (mensejero.next()){
                visVo= new PacienteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6), mensejero.getString(7));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
     
      public static PacienteVO ConsultarPorHabitacion(String Numero) {
         PacienteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT Descripcion_Enfermedad, Fecha_Nacimiento, ID_Paciente, Nombre_Paciente, Apellido_Paciente, Estado, Numero_Habitacion FROM `paciente` where Numero_Habitacion="+Numero);
            while (mensejero.next()){
                visVo= new PacienteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6), mensejero.getString(7));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
      
       public ArrayList<PacienteVO> ConsultarPorHabitacion2(String Nombre) {
        ConexionBD conBD= new ConexionBD();
        ArrayList<PacienteVO> listaVis= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT Descripcion_Enfermedad, Fecha_Nacimiento, ID_Paciente, Nombre_Paciente, Apellido_Paciente, Estado, Numero_Habitacion FROM `paciente` where Numero_Habitacion="+Nombre);
            while (mensajero.next()){
                id=mensajero.getString(3);
                nombre=mensajero.getString(4);
                apellido=mensajero.getString(5);                
                fechaNacimiento=mensajero.getString(2);
                desEnfermedad=mensajero.getString(1);
                idHabitacion=mensajero.getString(7);
                estado=mensajero.getString(6);
                PacienteVO pacVO=new PacienteVO(desEnfermedad, fechaNacimiento, id, nombre, apellido, estado, idHabitacion);
                listaVis.add(pacVO);                                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaVis;
       }
    
}
