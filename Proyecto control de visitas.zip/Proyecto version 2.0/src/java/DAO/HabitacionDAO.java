/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import util.ConexionBD;
import util.Metodos;
import VO.HabitacionVO;
import VO.UsuarioVO;
import VO.VisitanteVO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author APRENDIZ
 */
public class HabitacionDAO extends ConexionBD implements  Metodos{
    private Connection conexion=null;
    private Statement puente=null;
    private ResultSet mensajero=null;
    
    private int candPacientes=0,piso=0;
    private String numHabitacion="",estado="",horario="",tipoHabitacion="";
    private boolean operacion=false;
    public HabitacionDAO(HabitacionVO habVO){
        super();
        try {
            conexion=this.odtenerConecion();
            puente=conexion.createStatement();
            candPacientes= habVO.getCandPacientes();
            piso=habVO.getPiso();
            numHabitacion=habVO.getNumHabitacion();
            estado=habVO.getEstado();
            horario=habVO.getHorario();
            tipoHabitacion=habVO.getTipoHabitacion();
            
        } catch (Exception e) {           
        }
    }

    public HabitacionDAO() {
    }
    
    @Override    
    public boolean Registrar() {
        try {
           puente.executeUpdate("CALL `Reg_Habitacion`('"+numHabitacion+"', '"+candPacientes+"','"+tipoHabitacion+"','"+estado+"');");
           operacion=true;
           
        } catch (Exception e) {
            System.out.println("Error al registrar la habitacion : "+e.toString());
        }
        return  operacion;    
    }

    @Override
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `habitacion` SET `Tipo_Habitacion`='"+tipoHabitacion+"',`estado`='"+estado+"' WHERE `Numero_Habitacion`='"+numHabitacion+"'");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Error al actualizar la habitacion : "+e.toString());
        }
        return operacion;
    }    

    @Override
    public ArrayList<HabitacionVO> ConsultarT() {
        ConexionBD conBD=new ConexionBD();
        ArrayList<HabitacionVO> listaHab = new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT H.Numero_Habitacion,h.Piso,DH.Nombre,DH.Horario,DH.cadPacientes,H.Estado FROM habitacion H  NATURAL JOIN detalle_habitacion DH;");
            while (mensajero.next()) {
                numHabitacion=mensajero.getString(1);
                piso=mensajero.getInt(2);
                tipoHabitacion=mensajero.getString(3);                                
                horario=mensajero.getString(4);
                candPacientes=mensajero.getInt(5);
                estado=mensajero.getString(6);
                HabitacionVO habVO= new HabitacionVO(candPacientes, piso, numHabitacion, estado, horario, tipoHabitacion);
                listaHab.add(habVO);                
            }
        } catch (Exception e) {
            System.out.println("Error al llenar la arratlist : "+e.toString());
        }
        return listaHab;
    }
    public static HabitacionVO consultaEstado(String estado){/////preguntar funcionamiento
        HabitacionVO habVO=null;
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion=conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensajero=puente.executeQuery("SELECT * FROM `habitacion` WHERE estado='"+estado+"';");
            while (mensajero.next()) {
                //habVO=new HabitacionVO(mensajero.getString(1),mensajero.getInt(2),mensajero.getString(3),mensajero.getString(4));
            }
            mensajero.close();
            puente.close();
        } catch (Exception e) {
            System.out.println("Error en la consulta : "+e.toString());            
        }
        return habVO;
    }
    
        public static HabitacionVO consultaTipoHab(String tipoHab){/////preguntar funcionamiento
        HabitacionVO habVO=null;
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion=conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensajero=puente.executeQuery("");
            while (mensajero.next()) {
                habVO=new HabitacionVO(mensajero.getInt(3),mensajero.getString(2), mensajero.getString(4));
            }
            mensajero.close();
            puente.close();
        } catch (Exception e) {
            System.out.println("Error en la consulta : "+e.toString());            
        }
        return habVO;
    } 
        
        public List<HabitacionVO> Listarhabitacion(HabitacionVO Habitacion) {
            PreparedStatement instruccion=null;
            ResultSet resultado=null;
            List<HabitacionVO> habitaciones = new ArrayList<HabitacionVO>();
            
        odtenerConecion();

        try{
            String sSql = "";
            sSql = sSql + "SELECT Numero_Habitacion FROM habitacion where Estado = 'Disponible'";

            instruccion = conexion.prepareStatement(sSql);

            resultado=instruccion.executeQuery();

            
            while (resultado.next()) {
                Habitacion = new HabitacionVO();
                Habitacion.setNumHabitacion(resultado.getString(1));               
                habitaciones.add(Habitacion);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
               if (resultado != null) resultado.close();
               if (instruccion != null) instruccion.close();
            } catch (SQLException ex) {
            }
        }

        return habitaciones;
        }        
         public List<HabitacionVO> ListarTipo(HabitacionVO Habitacion) {
            PreparedStatement instruccion=null;
            ResultSet resultado=null;
            List<HabitacionVO> habitaciones = new ArrayList<HabitacionVO>();
            
        odtenerConecion();

        try{
            String sSql = "";
            sSql = sSql + "SELECT Horario, Nombre, cadPacientes FROM detalle_habitacion";

            instruccion = conexion.prepareStatement(sSql);

            resultado=instruccion.executeQuery();

            
            while (resultado.next()) {
                Habitacion = new HabitacionVO();
                Habitacion.setHorario(resultado.getString(1));   
                Habitacion.setTipoHabitacion(resultado.getString(2));
                Habitacion.setCandPacientes(resultado.getByte(3));               
                habitaciones.add(Habitacion);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
               if (resultado != null) resultado.close();
               if (instruccion != null) instruccion.close();
            } catch (SQLException ex) {
            }
        }

        return habitaciones;
        }
         
          public List<HabitacionVO> ListarNumero(HabitacionVO Habitacion) {
            PreparedStatement instruccion=null;
            ResultSet resultado=null;
            List<HabitacionVO> habitaciones = new ArrayList<HabitacionVO>();
            
        odtenerConecion();

        try{
            String sSql = "";
            sSql = sSql + "SELECT Numero_Habitacion FROM habitacion where Estado = 'Disponible'";

            instruccion = conexion.prepareStatement(sSql);

            resultado=instruccion.executeQuery();

            
            while (resultado.next()) {
                Habitacion = new HabitacionVO();
                Habitacion.setHorario(resultado.getString(1));                  
                habitaciones.add(Habitacion);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
               if (resultado != null) resultado.close();
               if (instruccion != null) instruccion.close();
            } catch (SQLException ex) {
            }
        }

        return habitaciones;
        }
          
          
       public static  HabitacionVO ConsultarPorNumero(String Num) {
         HabitacionVO habVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT DH.cadPacientes, H.Piso, H.Numero_Habitacion, H.Estado, DH.Horario, DH.Nombre FROM habitacion H  NATURAL JOIN detalle_habitacion DH where Numero_Habitacion="+Num);
            while (mensejero.next()){
                habVo= new HabitacionVO(mensejero.getInt(1),mensejero.getInt(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  habVo;
    }
       public ArrayList<HabitacionVO> ValidarDisponibilidad(String NumHab){       
        ConexionBD conBD= new ConexionBD();
        ArrayList<HabitacionVO> lista= new ArrayList<>();
        
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero = puente.executeQuery("SELECT COUNT(*), d.cadPacientes FROM habitacion h NATURAL JOIN detalle_habitacion d WHERE Numero_Habitacion='"+NumHab+"'");
            while (mensajero.next()) { 
                piso = mensajero.getInt(1);
                candPacientes = mensajero.getByte(2);
                HabitacionVO hvo = new HabitacionVO(piso, candPacientes);
                lista.add(hvo); 
            }
        }catch (Exception e) {
            System.out.println("Error: " + e.toString());
            
        }
        return lista;
    }
       
       public static HabitacionVO ConsultarPorId(String id) {
         HabitacionVO habVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT H.Numero_Habitacion,h.Piso,DH.Nombre,DH.Horario,DH.cadPacientes,H.Estado FROM habitacion H  NATURAL JOIN detalle_habitacion DH where Numero_Habitacion="+id);
            while (mensejero.next()){
                habVo= new HabitacionVO(mensejero.getInt(1),mensejero.getInt(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return habVo;
    }
     
      public static HabitacionVO ConsultarPorEstado2(String id) {
         HabitacionVO habVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT H.Numero_Habitacion,h.Piso,DH.Nombre,DH.Horario,DH.cadPacientes,H.Estado FROM habitacion H  NATURAL JOIN detalle_habitacion DH where Estado='"+id+"'");
            while (mensejero.next()){
                habVo= new HabitacionVO(mensejero.getInt(1),mensejero.getInt(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5), mensejero.getString(6));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  habVo;
    }
      public ArrayList<HabitacionVO> ConsultarPorEstado(String Nombre) {
        ConexionBD conBD= new ConexionBD();
        ArrayList<HabitacionVO> listaHab= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT H.Numero_Habitacion,h.Piso,DH.Nombre,DH.Horario,DH.cadPacientes,H.Estado FROM habitacion H  NATURAL JOIN detalle_habitacion DH where Estado='"+Nombre+"'");
            while (mensajero.next()){
                numHabitacion=mensajero.getString(1);
                piso=mensajero.getInt(2);
                tipoHabitacion=mensajero.getString(3);                                
                horario=mensajero.getString(4);
                candPacientes=mensajero.getInt(5);
                estado=mensajero.getString(6);
                HabitacionVO habVO= new HabitacionVO(candPacientes, piso, numHabitacion, estado, horario, tipoHabitacion);
                listaHab.add(habVO);                                  
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaHab;
      }
       
       
         
       
}

