/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author APRENDIZ
 */
public class ConexionBD {
    private String driver,urlBd,bD,usuario,clave;
    private Connection conexion;
    public ConexionBD(){
        driver="com.mysql.jdbc.Driver";
        bD="clinica_marly";
        usuario="root";
        clave="";
        urlBd="jdbc:mysql://localhost:3306/"+bD;
        try {
            Class.forName(driver).newInstance();
            conexion=DriverManager.getConnection(urlBd,usuario,clave);
            System.out.println("Conexion exitosa");
        } catch (Exception e) {
            System.out.println("Error al conectar la base de datos :"+e.toString());
        }
    }
    public Connection odtenerConecion(){        
        return conexion;
    }
    
    public Connection cerrarConexion() throws SQLException{
        conexion.close();
        conexion=null;
        return conexion;
    }
    public static void main(String[] args) {
        new ConexionBD();
        
    }
    
}