/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.ElementoDAO;
import DAO.PacienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.VisitanteVO;
import DAO.VisitanteDAO;
import VO.ElementoVO;
import VO.PacienteVO;

/**
 *
 * @author mille
 */
@WebServlet(name = "VisitanteControlador", urlPatterns = {"/Visitante"})
public class VisitanteControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String menu = request.getParameter("menu");
        String idVisitante = request.getParameter("txtIdentificacion");
        String nombre = request.getParameter("txtNombre");
        String apellido = request.getParameter("txtApellido");
        String fechaNacimiento = request.getParameter("txtFechaNacimiento");
        String parentesco = request.getParameter("txtParentesco");
        

        VisitanteVO visVO = new VisitanteVO(idVisitante, nombre, apellido, fechaNacimiento, parentesco);
        VisitanteDAO visDAO = new VisitanteDAO(visVO);

        switch (menu) {
            case "1":
                if (idVisitante.equals("") || nombre.equals("") || apellido.equals("") || fechaNacimiento.equals("") || parentesco.equals("")) {
                     request.setAttribute("MensajeCamposVacios","Complete los campos vacios.");   
                } else {
                    if (visDAO.Registrar()) {
                        request.setAttribute("MensajeExito", "El visitante se ha registrado con exito.");
                        
                    } else {
                        request.setAttribute("MensajeError", "El visitante ya exite en la base de datos");
                    }
                }
                request.getRequestDispatcher("RegistrarVisitante.jsp").forward(request, response);
                break; 
            case "2":
                 String idVis= request.getParameter("txtId");
                 VisitanteVO visVO1 = VisitanteDAO.ConsultarPorId(idVis);

                    if (visVO1 != null) {                       
                        request.setAttribute("lista", visVO1);
                        request.getRequestDispatcher("ActualizarVisitante.jsp").forward(request, response);
                    } else {
                        request.setAttribute("MensajeError", "El vehiculo no existe desea registrarlo ");                                                
                    }
                    break;
            case "3":             
                if (visDAO.Editar()) {
                    request.setAttribute("MensajeExitoa", "El visitante se ha actualizado con exito.");
                    
                } else {
                    request.setAttribute("MensajeErrora", "El visitante no se puedo actualizar");
                }               
                request.getRequestDispatcher("ConsultarVisitante.jsp").forward(request, response);
                break; 
            case "Consultar": 
                    String idpac= request.getParameter("selecID"); 
                    String Nombre= request.getParameter("selecNombre"); 
                    if (idpac.equals("") &&  Nombre.equals("")) {                        
                        request.setAttribute("lista", null);
                    }                   
                    else
                    {
                        if(idpac.equals(("")))
                        {
                            VisitanteVO pacVO2 = VisitanteDAO.ConsultarPorNombre2(Nombre);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaN", pacVO2);
                                 request.getRequestDispatcher("ConsultarVisitante.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no esta registrado en la base de datos. <br>");                                                
                             }                            
                        }   
                        else if(Nombre.equals(""))
                        {
                            VisitanteVO pacVO2 = VisitanteDAO.ConsultarPorId(idpac);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaI", pacVO2);
                                 request.getRequestDispatcher("ConsultarVisitante.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no esta registrado en la base de datos. <br>");                                                
                             }                            
                        }                          
                    }                   
                     request.getRequestDispatcher("ConsultarVisitante.jsp").forward(request, response);
                break; 
                
                  case "Elemento": 
                    String idvis= request.getParameter("txtIdentificacion");                     
                    VisitanteVO visVO2 = VisitanteDAO.ConsultarPorId(idvis);

                    if (visVO2 != null) {                       
                        request.setAttribute("lista", visVO2);
                        request.getRequestDispatcher("ConsultarElemento.jsp").forward(request, response);
                    } else {
                        request.setAttribute("MensajeError", "El vehiculo no existe desea registrarlo ");                                                
                    }                    
                    break; 
                        
                        
                    
                 case "Reporte":             
                //Reportes
                break; 
                    
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
