/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import VO.HabitacionVO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.ConexionBD;
import util.Metodos;
import VO.VisitanteVO;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
/**
 *
 * @author mille
 */
public class VisitanteDAO extends ConexionBD {

    public static VisitanteVO ConsultarPorID(String idvis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private  Connection conexion=null;
    private Statement puente=null;
    private ResultSet mensejero=null;
    private String idVisitante="",nombre="",apellido="",fechaNacimiento="",parentesco="";
    private boolean operaciones= false;

    public VisitanteDAO(VisitanteVO visVO) {
       super();
        try {
            conexion=this.odtenerConecion();
            puente=conexion.createStatement();
            idVisitante=visVO.getIdVisitante();
            nombre=visVO.getNombre();
            apellido=visVO.getApellido();
            fechaNacimiento=visVO.getFechaNacimiento();
            parentesco=visVO.getParentesco();
        } catch (Exception e) {
        }
    }

    public VisitanteDAO() {
    }

    

    public boolean Registrar() {
        try {
            puente.executeUpdate("CALL `Reg_Visitante`('"+idVisitante+"','"+nombre+"', '"+apellido+"', '"+fechaNacimiento+"', '"+parentesco+"');");
            operaciones=true;
        } catch (Exception e) {
            System.out.println("Error al registrar el visitante : "+e.toString());
        }
        return operaciones;
    }

     
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `visitante` SET `Relacion_Paciente`='"+parentesco+"' WHERE `ID_Visitante`='"+idVisitante+"'");
            operaciones=true;
        } catch (Exception e) {
            System.out.println("Erorr al actualizar el paciente : "+e.toString());
        }
        return  operaciones;
    }
  
    public ArrayList<VisitanteVO> ConsultarT() {
        ConexionBD conBD= new ConexionBD();
        ArrayList<VisitanteVO> listaVis= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensejero=puente.executeQuery("SELECT * FROM `visitante`");
            while (mensejero.next()){
                idVisitante=mensejero.getString(1);
                nombre=mensejero.getString(2);
                apellido=mensejero.getString(3);
                fechaNacimiento=mensejero.getString(4);
                parentesco=mensejero.getString(5);
                VisitanteVO visVO= new VisitanteVO(idVisitante, nombre, apellido, fechaNacimiento, parentesco);
                listaVis.add(visVO);                                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaVis;
    }
    
     public List<VisitanteVO> ListarIdVisitante(VisitanteVO Visitante) {
            PreparedStatement instruccion=null;
            ResultSet resultado=null;
            List<VisitanteVO> visitante = new ArrayList<VisitanteVO>();
            
        odtenerConecion();

        try{
            String sSql = "";
            sSql = sSql + "SELECT ID_Visitante, Nombre_Visitante, Apellido_Visitante FROM visitante";

            instruccion = conexion.prepareStatement(sSql);

            resultado=instruccion.executeQuery();

            
            while (resultado.next()) {
                Visitante = new VisitanteVO();
                Visitante.setIdVisitante(resultado.getString(1));  
                Visitante.setNombre(resultado.getString(2));   
                Visitante.setApellido(resultado.getString(3));  
                visitante.add(Visitante);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
               if (resultado != null) resultado.close();
               if (instruccion != null) instruccion.close();
            } catch (SQLException ex) {
            }
        }

        return visitante;
        }                             
     
     public static VisitanteVO ConsultarPorId(String id) {
         VisitanteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `visitante` where ID_Visitante="+id);
            while (mensejero.next()){
                visVo= new VisitanteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
     
      public static VisitanteVO ConsultarPorNombre2(String id) {
         VisitanteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `visitante` where Nombre_Visitante='"+id+"'");
            while (mensejero.next()){
                visVo= new VisitanteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
      public ArrayList<VisitanteVO> ConsultarPorNombre(String Nombre) {
        ConexionBD conBD= new ConexionBD();
        ArrayList<VisitanteVO> listaVis= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensejero=puente.executeQuery("SELECT * FROM `visitante` where Nombre_Visitante='"+Nombre+"'");
            while (mensejero.next()){
                idVisitante=mensejero.getString(1);
                nombre=mensejero.getString(2);
                apellido=mensejero.getString(3);
                fechaNacimiento=mensejero.getString(4);
                parentesco=mensejero.getString(5);
                VisitanteVO visVO= new VisitanteVO(idVisitante, nombre, apellido, fechaNacimiento, parentesco);
                listaVis.add(visVO);                                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaVis;
    }
    
    
}
