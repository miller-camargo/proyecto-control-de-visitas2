/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import DAO.PacienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.VigilanteVO;
import DAO.VigilanteDAO;
import DAO.VisitanteDAO;
import VO.PacienteVO;
import VO.VisitanteVO;

/**
 *
 * @author mille
 */
@WebServlet(name = "VigilanteControlador", urlPatterns = {"/Vigilante"})
public class VigilanteControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String menu = request.getParameter("menu");
        String correo = request.getParameter("txtEmail");
        String id = request.getParameter("txtIdentificacion");
        String nombre = request.getParameter("txtNombre");
        String estado = request.getParameter("txtEstado");
        String apellido = request.getParameter("txtApellido");

        VigilanteVO vigVO = new VigilanteVO(correo, id, nombre, apellido, estado);
        VigilanteDAO vigDAO = new VigilanteDAO(vigVO);

        switch (menu) {
            case "1":
                if (id.equals("") || nombre.equals("") || apellido.equals("") || correo.equals("")) {
                     request.setAttribute("MensajeCamposVacios","Complete los campos vacios.");                  
                } else {
                    if (vigDAO.Registrar()) {                                                
                        request.setAttribute("MensajeExito", "El vigilante se ha registrado correctamente");                       
                    } else {
                        request.setAttribute("MensajeError", "El vigilante ya esta registrado.");                        
                    }                     
                }
                request.getRequestDispatcher("RegistrarVigilante.jsp").forward(request, response);

                break;
                case "2":
                 String idVis= request.getParameter("txtId");
                 VigilanteVO pacVO1 = VigilanteDAO.ConsultarPorId(idVis);

                    if (pacVO1 != null) {                       
                        request.setAttribute("lista", pacVO1);
                        request.getRequestDispatcher("ActualizarVigilante.jsp").forward(request, response);
                    } else {
                        request.setAttribute("MensajeError", "El vehiculo no existe desea registrarlo ");                                                
                    }
                    break;
                case "Actualizar":
                if (vigDAO.Editar()) {
                    request.setAttribute("MensajeExito", "El vigilante se ha actualizado con exito.");
                    request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                } else {
                    request.setAttribute("MensajeError", "El vigilante no se puedo actualizar");
                    request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                }
                request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                break;
                case "Consultar": 
                    String idpac= request.getParameter("selecID"); 
                    String Nombre= request.getParameter("selecNombre"); 
                    if (idpac.equals("") &&  Nombre.equals("")) {                        
                        request.setAttribute("lista", null);
                    }                   
                    else
                    {
                        if(idpac.equals(("")))
                        {
                            VigilanteVO pacVO2 = VigilanteDAO.ConsultarPorNombre2(Nombre);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaN", pacVO2);
                                 request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no esta registrado en la base de datos. <br>");                                                
                             }                            
                        }   
                        else if(Nombre.equals(""))
                        {
                            VigilanteVO pacVO2 = VigilanteDAO.ConsultarPorId(idpac);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaI", pacVO2);
                                 request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no esta registrado en la base de datos. <br>");                                                
                             }                            
                        }                          
                    }                   
                     request.getRequestDispatcher("ConsultarVigilante.jsp").forward(request, response);
                break; 
                        
                        
                    
                 case "Reporte":             
                //Reportes
                break; 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
