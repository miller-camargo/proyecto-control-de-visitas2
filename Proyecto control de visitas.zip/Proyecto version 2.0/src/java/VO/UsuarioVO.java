/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VO;

/**
 *
 * @author APRENDIZ
 */
public class UsuarioVO {
    private String idVigilante;
    private String usuario,rol,clave;

    public UsuarioVO(String idVigilante, String usuario, String rol, String clave) {
        this.idVigilante = idVigilante;
        this.usuario = usuario;
        this.rol = rol;
        this.clave = clave;
    }

    public String getIdVigilante() {
        return idVigilante;
    }

    public void setIdVigilante(String idVigilante) {
        this.idVigilante = idVigilante;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
    
    
}
