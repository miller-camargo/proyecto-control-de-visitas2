/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import VO.VisitaVO;
import DAO.VisitaDAO;
import DAO.VisitanteDAO;
import VO.VisitanteVO;

/**
 *
 * @author mille
 */
@WebServlet(name = "VisitaControlador", urlPatterns = {"/Visita"})
public class VisitaControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String menu = request.getParameter("menu");
        String idVisita = request.getParameter("txtIdVisita");
        String fechaInicio = request.getParameter("txtFechaInicio");
        String fechaFin = request.getParameter("txtFechaInicio");
        String horaInicio = request.getParameter("txtHoraInicio");
        String horaFin = request.getParameter("txtHoraInicio");
        String IdVigilante = request.getParameter("txtIdVigilante");   
        String idPaciente = request.getParameter("txtIdPaciente");
        String idVisitante = request.getParameter("txtIdVisitante");    
        String Estado = request.getParameter("txtEstado");
        
        
        
       
         switch(menu){
            case "1":
                VisitaVO visVO=new VisitaVO(idVisita, fechaInicio, fechaFin,horaInicio,horaFin,IdVigilante,idPaciente,idVisitante,Estado);
                VisitaDAO visDAO=new VisitaDAO(visVO);
                 if (IdVigilante.equals("") || idPaciente.equals("") || idVisitante.equals("") || horaInicio.equals("")|| fechaInicio.equals("")) {
                     request.setAttribute("MensajeCamposVacios","Complete los campos vacios.");                  
                } else {
                    if (visDAO.Registrar()) {                                                
                        request.setAttribute("MensajeExito", "La Visita se ha registrado correctamente");                       
                    } else {
                        request.setAttribute("MensajeError", "La Visita ya esta registrado.");                        
                    }                     
                }
                request.getRequestDispatcher("RegistrarElemento.jsp").forward(request, response);
                break;
            case "2":
                VisitaVO visVO2=new VisitaVO(idVisita, fechaInicio, fechaFin,horaInicio,horaFin,IdVigilante,idPaciente,idVisitante,Estado);
                VisitaDAO visDAO2=new VisitaDAO(visVO2);                
                if (visDAO2.Editar()) {       
                    request.setAttribute("MensajeExito","");
                   request.getRequestDispatcher("").forward(request, response);
                }else {
                    request.setAttribute("MensajeError", "");
                    request.getRequestDispatcher("").forward(request, response);
                }
                break;   
                case "Estado":
                String idVis= request.getParameter("txtId");
                String rol= request.getParameter("cargo");
                String FechaFin= request.getParameter("FFin");
                String HoraFin= request.getParameter("HFin");
                VisitaVO visVO3=new VisitaVO(idVis, fechaInicio, FechaFin,horaInicio,HoraFin,IdVigilante,idPaciente,idVisitante,Estado);
                VisitaDAO visDAO3=new VisitaDAO(visVO3);
                if (visDAO3.Editar()) {       
                    request.setAttribute("MensajeExito","");
                    if(rol.equals("Administrador")){
                   request.getRequestDispatcher("MenuPrincipal.jsp").forward(request, response);
                    }else if(rol.equals("Vigilante")){
                        request.getRequestDispatcher("MenuSecundario.jsp").forward(request, response);
                    }
                }else {
                    request.setAttribute("MensajeError", "");
                    if(rol.equals("Administrador")){
                   request.getRequestDispatcher("MenuPrincipal.jsp").forward(request, response);
                    }else if(rol.equals("Vigilante")){
                        request.getRequestDispatcher("MenuSecundario.jsp").forward(request, response);
                    }
                }
                break;   
                case "Consultar": 
                    String paciente= request.getParameter("selecPaciente"); 
                    String visitante= request.getParameter("selecVisitante"); 
                    String fecha= request.getParameter("textFecha"); 
                    if (paciente.equals("") &&  visitante.equals("") && fecha.equals("")) {                        
                        request.setAttribute("lista", null);
                    }                   
                    else
                    {
                        if(paciente.length()>1)
                        {
                            VisitaVO pacVO2 = VisitaDAO.ConsultarPorPaciente2(paciente);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaP", pacVO2);
                                 request.getRequestDispatcher("ConsultarVisita.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El paciente no ha recibido visitas <br>");                                                
                             }                            
                        }   
                        else if(visitante.length()>1)
                        {
                            VisitaVO pacVO2 = VisitaDAO.ConsultarPorVisitante2(visitante);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaV", pacVO2);
                                 request.getRequestDispatcher("ConsultarVisita.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no ha registrado visitas <br>");                                                
                             }                            
                        } 
                        else if(fecha.length()>0)
                        {
                            VisitaVO pacVO2 = VisitaDAO.ConsultarPorPaciente2(fecha);
                             if (pacVO2 != null) {                       
                                 request.setAttribute("listaF", pacVO2);
                                 request.getRequestDispatcher("ConsultarVisita.jsp").forward(request, response);
                             } else {
                                 request.setAttribute("MensajeError", "El Visitante no esta registrado en la base de datos. <br>");                                                
                             }                            
                        } 
                    }                   
                     request.getRequestDispatcher("ConsultarVisita.jsp").forward(request, response);
                break; 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
