/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VO;

/**
 *
 * @author mille
 */
public class VigilanteVO extends Persona{
    
    private String correo;

    public VigilanteVO() {
        
    }

    
    public VigilanteVO(String correo, String id, String nombre, String apellido, String estado) {
        super(id, nombre, apellido, estado);
        this.correo = correo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }    
}
