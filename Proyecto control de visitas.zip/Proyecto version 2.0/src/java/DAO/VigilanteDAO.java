/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.*;
import VO.VigilanteVO;
import VO.VisitanteVO;
/**
 *
 * @author mille
 */
public class VigilanteDAO extends ConexionBD implements Metodos{

    private Connection conexion;
    private Statement puente;
    private ResultSet mensajero;
    private String correo="", id="",nombre="",apellido="",estado="";
    private boolean operacion=false;

    public VigilanteDAO() {
    }

    public VigilanteDAO(VigilanteVO vigVO) {
        super();
        try {
            conexion=this.odtenerConecion();
            puente=conexion.createStatement();
            
            correo=vigVO.getCorreo();
            id=vigVO.getId();
            nombre=vigVO.getNombre();
            apellido= vigVO.getApellido();
            estado=vigVO.getEstado();                                    
        } catch (Exception e) {
            System.out.println("Error en el constructor: "+e.toString());
        }
    }
            
    @Override
    public boolean Registrar() {
        try {
            puente.executeUpdate(" CALL `Reg_Vigilante`('"+id+"', '"+nombre+"', '"+apellido+"', '"+correo+"', 'Activo');");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Error al registrar el vigilante: "+e.toString());
        }
        return  operacion;
    }

    @Override
    public boolean Editar() {
        try {
            puente.executeUpdate("UPDATE `vigilante` SET `Correo_Vigilante`='"+correo+"',`Estado`='"+estado+"' WHERE `ID_Vigilante`='"+id+"'");
            operacion=true;
        } catch (Exception e) {
            System.out.println("Error al actualizar el vigilante : "+e.toString());
        }
        return operacion;
    }

    @Override
    public ArrayList<VigilanteVO> ConsultarT() {
       ConexionBD conBD= new ConexionBD();
       ArrayList<VigilanteVO> listaVig= new ArrayList<>();
        try {
            puente=conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `vigilante`");
            while (mensajero.next()) {
                id=mensajero.getString(1);
                nombre=mensajero.getString(2);
                apellido=mensajero.getString(3);
                correo=mensajero.getString(4);
                estado=mensajero.getString(5);
                VigilanteVO vigVO= new VigilanteVO(correo, id, nombre, apellido, estado);
                listaVig.add(vigVO);
            }   
        } catch (Exception e) {
            System.out.println("Error al consultar los vigilantes :"+e.toString());
        }
        return listaVig;
    }
    
     public static VigilanteVO datosVigilante(String Id)
    {
        VigilanteVO VigVO = null;
        try {

            ConexionBD conBD = new ConexionBD();
            Connection conexion = conBD.odtenerConecion();
            Statement puente = conexion.createStatement();
            ResultSet mensajero = puente.executeQuery("SELECT Correo_Vigilante, ID_Vigilante, Nombre_Vigilante, Apellido_Vigilante, Estado from vigilante WHERE ID_Vigilante='"+Id+"'");
            while (mensajero.next()) {
                VigVO = new VigilanteVO(mensajero.getString(1), mensajero.getString(2), mensajero.getString(3), mensajero.getString(4), mensajero.getString(5));
            }
            mensajero.close();
            puente.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
        return VigVO;
    }
      public static VigilanteVO ConsultarPorId(String id) {
         VigilanteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT Correo_Vigilante, ID_Vigilante, Nombre_Vigilante, Apellido_Vigilante, Estado FROM `vigilante` where ID_Vigilante="+id);
            while (mensejero.next()){
                visVo= new VigilanteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
     
      public static VigilanteVO ConsultarPorNombre2(String id) {
         VigilanteVO visVo=null;
                         
        try {
            ConexionBD conBD= new ConexionBD();
            Connection conexion= conBD.odtenerConecion();
            Statement puente= conexion.createStatement();
            ResultSet mensejero=puente.executeQuery("SELECT * FROM `vigilante` where Nombre_Vigilante='"+id+"'");
            while (mensejero.next()){
                visVo= new VigilanteVO(mensejero.getString(1), mensejero.getString(2), mensejero.getString(3), mensejero.getString(4), mensejero.getString(5));
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  visVo;
    }
      public ArrayList<VigilanteVO> ConsultarPorNombre(String Nombre) {
        ConexionBD conBD= new ConexionBD();
        ArrayList<VigilanteVO> listaVis= new ArrayList<>();
        try {
            puente= conBD.odtenerConecion().createStatement();
            mensajero=puente.executeQuery("SELECT * FROM `vigilante` where Nombre_Vigilante='"+Nombre+"'");
            while (mensajero.next()){
                id=mensajero.getString(1);
                nombre=mensajero.getString(2);
                apellido=mensajero.getString(3);
                correo=mensajero.getString(4);
                apellido=mensajero.getString(5);
                VigilanteVO visVO= new VigilanteVO(id, nombre, apellido, correo, apellido);
                listaVis.add(visVO);                                
            }
        } catch (Exception e) {
            System.out.println("Error al consultar todo :"+e.toString());
        }
        return  listaVis;
    }
    
    
    
}
